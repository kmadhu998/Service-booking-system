package com.madhu.servicebooking.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.madhu.servicebooking.model.ServiceEntity;

public interface ServiceRepository extends JpaRepository<ServiceEntity, Long> {
}