package com.madhu.servicebooking.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.madhu.servicebooking.model.ServiceEntity;
import com.madhu.servicebooking.service.ServiceEntityService;

@RestController
@RequestMapping("/services")
public class ServiceController {

    @Autowired
    private ServiceEntityService service;

    @PostMapping
    public ServiceEntity create(@RequestBody ServiceEntity entity) {
        return service.save(entity);
    }

    @GetMapping
    public List<ServiceEntity> getAll() {
        return service.getAll();
    }
}