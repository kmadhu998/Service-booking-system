package com.madhu.servicebooking.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.madhu.servicebooking.model.Booking;
import com.madhu.servicebooking.repository.BookingRepository;

@Service
public class BookingService {

    @Autowired
    private BookingRepository repository;

    public Booking save(Booking booking) {
        return repository.save(booking);
    }

    public List<Booking> getAll() {
        return repository.findAll();
    }
}