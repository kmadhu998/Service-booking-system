package com.madhu.servicebooking.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.madhu.servicebooking.model.Role;
import com.madhu.servicebooking.model.User;
import com.madhu.servicebooking.repository.UserRepository;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;
    @Autowired
    private PasswordEncoder passwordEncoder;
    // Register user
    public User registerUser(User user) {

        // encrypt password
        user.setPassword(passwordEncoder.encode(user.getPassword()));

        // set default role
        user.setRole(Role.USER);

        return userRepository.save(user);
    }

    // Get all users
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    // Get user by id
    public User getUserById(Long id) {
        return userRepository.findById(id).orElse(null);
    }
}