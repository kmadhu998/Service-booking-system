package com.madhu.servicebooking.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.madhu.servicebooking.model.ServiceEntity;
import com.madhu.servicebooking.repository.ServiceRepository;

@Service
public class ServiceEntityService {

    @Autowired
    private ServiceRepository repository;

    public ServiceEntity save(ServiceEntity service) {
        return repository.save(service);
    }

    public List<ServiceEntity> getAll() {
        return repository.findAll();
    }
}