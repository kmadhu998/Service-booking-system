package com.madhu.servicebooking.model;

public enum Role {
    USER,
    ADMIN
}